public enum CarType {//assuming two types of cars
    ICE,ELECTRIC
}
