import java.util.*;
public class Main {
    public static void main(String[] args) {
        ArrayList<Car> cars = Functionality.load();
        if (cars == null ) {
            cars = new ArrayList<>();
        }
        Functionality.menu(cars);

    }
}

