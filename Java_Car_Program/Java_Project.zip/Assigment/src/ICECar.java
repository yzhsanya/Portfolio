public class ICECar extends Car {

    public ICECar(String make, String model, int year, CarType carType) {
        super(make, model, year, carType);
    }
}
