import java.util.Date;

public class ElectricCar extends Car{
    final int batteryCapacity;
    public ElectricCar(String make, String model, int year, CarType carType,int batteryCapacity) {
        super(make, model, year, carType);
        this.batteryCapacity = batteryCapacity;// adding additional property to a  subclass
        ;
    }

    public int getBatteryCapacity() {
        return batteryCapacity;
    } //getter for a new property


}
