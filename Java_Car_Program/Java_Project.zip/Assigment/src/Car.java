import java.io.Serializable;
public class Car implements Serializable,Comparable<Car> {
    private String make;
    private String model;                                                                   //properties
    private int year;
    private final CarType carType;
    public Car(String make, String model,int year,CarType carType) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.carType = carType;

    }
    public String getMake() {
        return make;
    }
    public void setMake(String make) {
        this.make = make;
    }                                                               //setters and getters
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public CarType getCarType() {
        return carType;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }


    @Override
    public int compareTo(Car other) {
        return carType.compareTo(other.carType);
    }                       //compareTo to compare enum for sorting
}

