import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;
class CarTest {
    ArrayList<Car>cars=new ArrayList<>();
    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        cars.add(new ICECar("Toyota", "CHR", 2022, CarType.ICE));
        cars.add(new ElectricCar("Tesla", "ModelX", 2024, CarType.ELECTRIC,1000));
    }
    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }
    @org.junit.jupiter.api.Test
    void getMake() {
        assertEquals("Toyota", cars.get(0).getMake());
        assertEquals("Tesla", cars.get(1).getMake());
    }
    @org.junit.jupiter.api.Test
    void setMake() {
        cars.get(0).setMake("Not Toyota");
        assertEquals("Not Toyota", cars.get(0).getMake());
        cars.get(1).setMake("Not Tesla");
        assertEquals("Not Tesla", cars.get(1).getMake());
    }
    @org.junit.jupiter.api.Test
    void getModel() {
        assertEquals("CHR", cars.get(0).getModel());
        assertEquals("ModelX", cars.get(1).getModel());
    }
    @org.junit.jupiter.api.Test
    void setModel() {
        cars.get(0).setModel("Not CHR");
        assertEquals("Not CHR", cars.get(0).getModel());
        cars.get(1).setModel("Not ModelX");
        assertEquals("Not ModelX", cars.get(1).getModel());
    }
    @org.junit.jupiter.api.Test
    void getCarType() {
        assertEquals(CarType.ICE, cars.get(0).getCarType());
        assertEquals(CarType.ELECTRIC, cars.get(1).getCarType());
    }
    @org.junit.jupiter.api.Test
    void getYear() {
        assertEquals(2022, cars.get(0).getYear());
        assertEquals(2024, cars.get(1).getYear());
    }
    @org.junit.jupiter.api.Test
    void setYear() {
        cars.get(0).setYear(2020);
        assertEquals(2020, cars.get(0).getYear());
        cars.get(1).setYear(2019);
        assertEquals(2019, cars.get(1).getYear());
    }
}